package ni.edu.uca.flashserviceproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button


class RecuperarPassword : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recuperar_password)

        val atras = findViewById<Button>(R.id.btn_atras)

        atras.setOnClickListener {
            val intento3 = Intent (this, IniciarSesion::class.java)
            startActivity(intento3)
        }

    }
}