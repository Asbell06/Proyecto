package ni.edu.uca.flashserviceproject.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "Servicios")
class Servicio (
    val nombre:String,
    val monto: Double,
    val mes: String,
    @PrimaryKey(autoGenerate = true)
    var idServicio: Int = 0

    ) : Serializable