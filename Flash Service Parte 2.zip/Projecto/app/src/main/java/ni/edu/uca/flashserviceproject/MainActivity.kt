package ni.edu.uca.flashserviceproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import ni.edu.uca.flashserviceproject.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.btnRegistrarse.setOnClickListener {
            startActivity(Intent(this, RegistroUsuario()::class.java))
        }

        binding.btnIniciarSesion.setOnClickListener {
            startActivity(Intent(this, IniciarSesion()::class.java))
        }


    }


}