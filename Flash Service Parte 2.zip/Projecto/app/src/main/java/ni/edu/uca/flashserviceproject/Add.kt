package ni.edu.uca.flashserviceproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import kotlinx.android.synthetic.main.activity_add.*
import ni.edu.uca.flashserviceproject.data.AppDatabase
import ni.edu.uca.flashserviceproject.data.Servicio

class Add : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        var listaServicios = emptyList<Servicio>()

        val database = AppDatabase.getDatabase(this)

        database.servicios().getAll().observe(this, Observer {
            listaServicios = it

           val adapter = ServiciosAdapter (this, listaServicios)

            lista.adapter = adapter
        })



        lista.setOnItemClickListener{parent, view, position, id ->
            val intent = Intent(this, ServicioActivity::class.java)
            intent.putExtra("id", listaServicios[position].idServicio)
            startActivity(intent)
        }

           fab_add.setOnClickListener{
            val intent = Intent (this, NuevoServicio::class.java)
            startActivity(intent)
        }
    }
}