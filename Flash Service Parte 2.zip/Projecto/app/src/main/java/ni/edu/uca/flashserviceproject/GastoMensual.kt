package ni.edu.uca.flashserviceproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class GastoMensual : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gasto_mensual)

        val atras = findViewById<Button>(R.id.btn_atras)

        atras.setOnClickListener {
            val intento2 = Intent (this, ServicioMenu::class.java)
            startActivity(intento2)
        }
    }
}
