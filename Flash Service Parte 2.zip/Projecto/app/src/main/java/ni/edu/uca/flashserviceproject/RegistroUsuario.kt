package ni.edu.uca.flashserviceproject


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import ni.edu.uca.flashserviceproject.databinding.ActivityRegistroUsuarioBinding


class RegistroUsuario : AppCompatActivity() {
    private lateinit var binding: ActivityRegistroUsuarioBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro_usuario)

        val guardar = findViewById<Button>(R.id.btnGuardar)
        val atras = findViewById<Button>(R.id.btn_atras)


        guardar.setOnClickListener {
            val intento1 = Intent(this, ServicioMenu::class.java)
            startActivity(intento1)
        }

        atras.setOnClickListener {
            val intento3 = Intent(this, MainActivity::class.java)
            startActivity(intento3)
        }

    }
}