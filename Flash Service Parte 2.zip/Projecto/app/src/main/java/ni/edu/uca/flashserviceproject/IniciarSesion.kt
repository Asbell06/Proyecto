package ni.edu.uca.flashserviceproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView


class IniciarSesion : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_iniciar_sesion)

        val iniciar = findViewById<Button>(R.id.btn_iniciar)
        val atras = findViewById<Button>(R.id.btn_atras)
        val contraseña = findViewById<TextView>(R.id.btn_recuperar)

        iniciar.setOnClickListener {
            val intento1 = Intent (this, ServicioMenu::class.java)
            startActivity(intento1)
        }

        atras.setOnClickListener {
            val intento2 = Intent (this, MainActivity::class.java)
            startActivity(intento2)
        }

        contraseña.setOnClickListener {
            val intento3 = Intent (this, RecuperarPassword::class.java)
            startActivity(intento3)
        }
    }
}